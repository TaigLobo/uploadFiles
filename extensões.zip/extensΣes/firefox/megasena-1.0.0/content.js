var totalPreenchidas = 0;

var listaDezenas = data.listaDezenas.split('\n');
var totalJogos = data.totalJogos;
var statusProcessamento = 'Processando bilhetes...';
var tagJogo = data.tagJogo;
var totalPadraoDz = data.padraoDezena;

var totalCarrinhoInicio = parseInt(document.querySelector('#carrinho').innerText);
var sucesso = false;

listaDezenas.forEach(function (dezenas, i) {

    setTimeout(() => {

        if (/^(0[0-9]|[1-5][0-9])(\s(0[0-9]|[1-5][0-9])){5}$/.test(dezenas)) {

            dezenas = dezenas.trim();
            var numeros = dezenas.split(',');

            var totalDz = numeros.length - totalPadraoDz;
            for (var i = 0; i < totalDz; i++) {
                $('#aumentarnumero')[0].click();
            }

            numeros.forEach(function (valor) {
                $('#n' + valor.padStart(2, 0))[0].click();
            });

            totalPreenchidas++;

            $("#colocarnocarrinho")[0].click();

            var totalCarrinho = parseInt(document.querySelector('#carrinho').innerText);;

            var porc = Math.ceil((100 / totalJogos) * totalPreenchidas);

            if (porc == 100) {

                var totalBase = totalPreenchidas + totalCarrinhoInicio;

                if (totalBase == totalCarrinho) {
                    statusProcessamento = 'Processo concluído com sucesso. Confira o carrinho se a quantidade de jogos está correta...';
                    sucesso = true;
                } else {
                    statusProcessamento = 'Processo concluído com sucesso. Talvez o número de jogos não seja o mesmo dos informados, Confira o carrinho se a quantidade de jogos está correta...';
                    sucesso = true;
                }

            }

            var data = {
                "totalCarrinho": totalCarrinho,
                "totalPreenchidas": totalPreenchidas,
                "status": statusProcessamento,
                "progresso": porc,
                "sucesso": sucesso
            };

            chrome.runtime.sendMessage(data);

        }

    }, i * 500);

});