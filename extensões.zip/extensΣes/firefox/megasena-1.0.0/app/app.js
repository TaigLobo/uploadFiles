const TITULO = 'Aposte Megasena';

const URL_CAIXA = 'https://www.loteriasonline.caixa.gov.br';
const URL_CAIXA_LOTOFACIL = 'https://www.loteriasonline.caixa.gov.br/silce-web/#/mega-sena';
const URL_CAIXA_LOTOFACIL_INDEP = 'https://www.loteriasonline.caixa.gov.br/silce-web/#/mega-sena/especial';
const URL_BASE_JOGO = 'https://www.loteriasonline.caixa.gov.br/silce-web/#/';

const ETAPA_URL_INVALIDA = 'URL_INVALIDA';
const ETAPA_JOGO = 'JOGO';
const ETAPA_PROGRESSO = 'PROGRESSO';
const ETAPA_HOME_CAIXA = 'HOME_CAIXA'

const URLS_JOGOS_CAIXA = [URL_CAIXA_LOTOFACIL,
    URL_CAIXA_LOTOFACIL_INDEP
];

var jogoEmUSo = '';

function isUrlCaixaJogo(url){
    return URLS_JOGOS_CAIXA.includes(url);
}

function isUrlHomeCaixa(url){
    var base = url.split('/');
    var urlHome = base[0] + '//' + base[1] + base[2];
    return urlHome == URL_CAIXA;
}

function nomeJogoAtivo(urlTag){
    var tag = urlTag.substr(urlTag.lastIndexOf('/') + 1);

    if (tag == 'especial'){
        if (urlTag.includes('mega-sena')){
            tag = 'mega-sena/especial';
        }
    }

    switch(tag) {
        case 'mega-sena':
                return [tag, 'MegaSena', 'Cole os jogos exportado da Mega Sena!', 15];
            break;
        case 'mega-sena/especial':
                return [tag, 'Mega da Virada', 'Cole os jogos exportado da Mega da Virada', 15];
            break;
    }
}

function totalJogos(){
    var linhas = $('#dezenas').val().split('\n');
    var total = 0;
    linhas.forEach(function (linha) {
        if (/^(0[0-9]|[1-5][0-9])(\s(0[0-9]|[1-5][0-9])){5}$/.test(linha)) {

            total++;
        }
    });
    return total;
}

function etapa(etapa, nomeJogo = '', descricao = ''){
        console.log(etapa);
    if (etapa == ETAPA_URL_INVALIDA){
        $('#etapa_jogo').removeClass('d-block').addClass('d-none');
        $('#etapa_progresso').removeClass('d-block').addClass('d-none');
        $('#etapa_home').removeClass('d-block').addClass('d-none');
        $('#etapa_aviso').removeClass('d-none').addClass('d-block');
    }

    if (etapa == ETAPA_JOGO ){
        $('#etapa_aviso').removeClass('d-block').addClass('d-none');
        $('#etapa_progresso').removeClass('d-block').addClass('d-none');
        $('#etapa_home').removeClass('d-block').addClass('d-none');
        $('#etapa_jogo').removeClass('d-none').addClass('d-block');
        $('#jogo_ativo').text(nomeJogo);
        $('#descricao_dezenas').text(descricao);
    }

    if (etapa == ETAPA_PROGRESSO){
        $('#etapa_aviso').removeClass('d-block').addClass('d-none');
        $('#etapa_jogo').removeClass('d-block').addClass('d-none');
        $('#etapa_home').removeClass('d-block').addClass('d-none');
        $('#etapa_progresso').removeClass('d-none').addClass('d-block');
    }

    if (etapa == ETAPA_HOME_CAIXA){
        $('#etapa_aviso').removeClass('d-block').addClass('d-none');
        $('#etapa_jogo').removeClass('d-block').addClass('d-none');
        $('#etapa_progresso').removeClass('d-block').addClass('d-none');
        $('#etapa_home').removeClass('d-none').addClass('d-block');
    }
}

$(document).ready(function(){
    chrome.tabs.query({active: true,lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        console.log(tab);
        startApp(tab.url);
    });
});

function startApp(url){
    if (isUrlCaixaJogo(url)){
        jogoEmUso = nomeJogoAtivo(url);
        etapa(ETAPA_JOGO, nomeJogoAtivo(url)[1], nomeJogoAtivo(url)[2]);
    }else{
        if (isUrlHomeCaixa(url)){
            etapa(ETAPA_HOME_CAIXA);
        }else{
            etapa(ETAPA_URL_INVALIDA);
        }
    }
}

$('#preencher_cartelas').click(function(){
    $('#total_jogos').text(totalJogos());
    $('#total_jogos_progresso').text(totalJogos());
    $('#cartelas_preenchidas').text('0');
    $('#qtde_carrinho').text('0');
    $('#status').text('Aguarde ...')
    $('#fechar').addClass('disabled');
    etapa(ETAPA_PROGRESSO);

    var data = {"jogo": jogoEmUso[1],
                "tagJogo": jogoEmUso[0],
                "padraoDezena": jogoEmUso[3],
                "listaDezenas": $('#dezenas').val(),
                "totalJogos": totalJogos()};

    chrome.tabs.executeScript(null, {
        code: 'var data = ' + JSON.stringify(data),
    }, function() {
        chrome.tabs.executeScript(null, {file: 'js/jquery.min.js'}, function(){
            chrome.tabs.executeScript(null, {file:'content.js'});
        });
    });
});

$('#link_home').click(function(){
    etapa(ETAPA_HOME_CAIXA);
});

$('#link_site').click(function(){
    var win = window.open('https://minhalotofacil.com.br/', '_blank');
    win.focus();
});

$('#dezenas').bind('input propertychange', function() {
    var total = totalJogos();

    if (total > 0){
        $('#preencher_cartelas').prop('disabled', false);
    }else{
        $('#preencher_cartelas').prop('disabled', true);
    }

    $('#total_jogos').text(`Total: ${total} jogo(s)`)
});

$('.btnjogo').click(function(e){
    var jogo = $(this).data('jogo');
    chrome.tabs.update({url: URL_BASE_JOGO + jogo});
    jogoEmUso = nomeJogoAtivo(jogo);
    etapa(ETAPA_JOGO, nomeJogoAtivo(jogo)[1], nomeJogoAtivo(jogo)[2]);
});

$('#acessar_home_caixa').click(function(){
    chrome.tabs.update({url:URL_CAIXA_LOTOFACIL});
    window.close();
});

$('#fechar').click(function(){
    window.close();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    $('#progresso').attr('style', `width: ${request.progresso}%`);
    $('#cartelas_preenchidas').text(request.totalPreenchidas);
    $('#qtde_carrinho').text(request.totalCarrinho);
    $('#status').text(request.status);

    if (request.progresso == 100){
        $('#fechar').removeClass('disabled');

        $('#progresso').removeClass('bg-info');

        if (request.sucesso){
            $('#progresso').removeClass('bg-danger').addClass('bg-success');
        }else{
            $('#progresso').removeClass('bg-success').addClass('bg-danger');
        }

    }

});

